var botBtn = new Vue({
    el : "#botBtn",
    methods:{
        saveBtn : function(event){
            alert("save");
        },
        deleteBtn : function(event){
            alert("delete");
        }
    }
})